import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:trexven_operations/trexven_operations.dart';
import '../../services/database_service.dart';
import '../inventory/inventory_tab.dart';
import '../finance/operational_finance_screen.dart';
import '../intelligence/alerts_screen.dart';
import 'employment_screen.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/app_theme.dart';

class NotificationsSettingsScreen extends StatefulWidget {
  const NotificationsSettingsScreen({super.key});

  @override
  State<NotificationsSettingsScreen> createState() =>
      _NotificationsSettingsScreenState();
}

class _NotificationsSettingsScreenState
    extends State<NotificationsSettingsScreen> {
  bool _notificationsEnabled = true;
  bool _lowStock = true;
  bool _sales = true;
  bool _aiAlerts = true;
  bool _security = true;

  String _frequency = 'Instant';

  bool _loading = true;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _openInbox() async {
    try {
      final id = await DatabaseService().getCurrentBusinessId();
      if (!mounted) return;
      if (id == null) throw StateError('Verified owner business required.');
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => NotificationCenterScreen(
            api: OperationsClient(Supabase.instance.client, id),
            open: (context, route, referenceId) {
              final Widget screen = switch (route) {
                'inventory' => const InventoryTab(),
                'cash' => const OperationalFinanceScreen(),
                'employees' => const EmploymentScreen(),
                'vision' => const AlertsScreen(),
                _ => const Scaffold(
                  body: Center(
                    child: Text(
                      'This notification has no supported destination.',
                    ),
                  ),
                ),
              };
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => screen),
              );
            },
          ),
        ),
      );
    } catch (_) {
      if (mounted)
        _showMessage(
          'Verified owner notification access is unavailable.',
          isError: true,
        );
    }
  }

  Future<void> _loadSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      if (!mounted) return;

      setState(() {
        _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
        _lowStock = prefs.getBool('notify_low_stock') ?? true;
        _sales = prefs.getBool('notify_sales') ?? true;
        _aiAlerts = prefs.getBool('notify_ai_alerts') ?? true;
        _security = prefs.getBool('notify_security') ?? true;
        _frequency = 'Instant';
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _error = 'Unable to load notification settings.';
        _loading = false;
      });
    }
  }

  Future<void> _updateBool(String key, bool value) async {
    setState(() => _saving = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(key, value);

      if (!mounted) return;

      setState(() {
        switch (key) {
          case 'notifications_enabled':
            _notificationsEnabled = value;
            break;
          case 'notify_low_stock':
            _lowStock = value;
            break;
          case 'notify_sales':
            _sales = value;
            break;
          case 'notify_ai_alerts':
            _aiAlerts = value;
            break;
          case 'notify_security':
            _security = value;
            break;
        }
      });
    } catch (_) {
      _showMessage(
        'Unable to save your notification preference.',
        isError: true,
      );
    } finally {
      if (mounted) {
        setState(() => _saving = false);
      }
    }
  }

  Future<void> _updateFrequency(String value) async {
    setState(() {
      _saving = true;
      _frequency = value;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('notification_frequency', value);
    } catch (_) {
      _showMessage('Unable to save notification frequency.', isError: true);
    } finally {
      if (mounted) {
        setState(() => _saving = false);
      }
    }
  }

  void _showMessage(String message, {bool isError = false}) {
    if (!mounted) return;
    final theme = Theme.of(context);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: isError
            ? (theme.trexvenColors.error ?? const Color(0xFFDC2626))
            : (theme.trexvenColors.success ?? const Color(0xFF16A34A)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.trexvenColors.muted ?? Colors.grey;

    if (_loading) {
      return Scaffold(
        body: Center(
          child: CircularProgressIndicator(color: theme.colorScheme.primary),
        ),
      );
    }

    if (_error != null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text(
            'Notifications',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          elevation: 0,
          foregroundColor: theme.colorScheme.onSurface,
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.error_outline_rounded,
                  size: 48,
                  color: theme.trexvenColors.error,
                ),
                const SizedBox(height: 16),
                Text(
                  _error!,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: muted),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _loading = true;
                      _error = null;
                    });
                    _loadSettings();
                  },
                  child: const Text('Try Again'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Notifications',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20),
        ),
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: theme.colorScheme.onSurface,
        actions: [
          if (_saving)
            const Padding(
              padding: EdgeInsets.only(right: 20),
              child: Center(
                child: SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
        children: [
          ListTile(
            leading: const Icon(Icons.inbox_outlined),
            title: const Text('Open business notifications'),
            subtitle: const Text(
              'Current authorized alerts, employee changes and reconciliation reviews with personal read status.',
            ),
            onTap: _openInbox,
          ),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'The preferences below are stored on this device. Push notification delivery has not been configured.',
            ),
          ),
          _section(theme, 'General', [
            _item(
              theme,
              icon: Icons.notifications_active_outlined,
              title: 'Notifications',
              subtitle: 'Enable TREXVEN notifications on this device',
              value: _notificationsEnabled,
              onChanged: (value) {
                _updateBool('notifications_enabled', value);
              },
            ),
          ]),

          const SizedBox(height: 24),

          Opacity(
            opacity: _notificationsEnabled ? 1 : 0.5,
            child: IgnorePointer(
              ignoring: !_notificationsEnabled,
              child: Column(
                children: [
                  _section(theme, 'Inventory & Sales', [
                    _item(
                      theme,
                      icon: Icons.inventory_2_outlined,
                      title: 'Low Stock Alerts',
                      subtitle:
                          'Notify me when products fall below their stock threshold',
                      value: _lowStock,
                      onChanged: (value) {
                        _updateBool('notify_low_stock', value);
                      },
                    ),
                    _divider(theme),
                    _item(
                      theme,
                      icon: Icons.receipt_long_outlined,
                      title: 'Sales Summary',
                      subtitle: 'Receive notifications about business sales',
                      value: _sales,
                      onChanged: (value) {
                        _updateBool('notify_sales', value);
                      },
                    ),
                  ]),

                  const SizedBox(height: 24),

                  _section(theme, 'Vision & Security', [
                    _item(
                      theme,
                      icon: Icons.visibility_outlined,
                      title: 'Vision AI Alerts',
                      subtitle:
                          'Alert me about important TREXVEN Vision detection events',
                      value: _aiAlerts,
                      onChanged: (value) {
                        _updateBool('notify_ai_alerts', value);
                      },
                    ),
                    _divider(theme),
                    _item(
                      theme,
                      icon: Icons.shield_outlined,
                      title: 'Security Alerts',
                      subtitle:
                          'Sign-ins, password changes and important security activity',
                      value: _security,
                      onChanged: (value) {
                        _updateBool('notify_security', value);
                      },
                    ),
                  ]),

                  const SizedBox(height: 24),

                  _frequencySection(theme),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _frequencySection(ThemeData theme) {
    final muted = theme.trexvenColors.muted ?? Colors.grey;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Notification Frequency',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: theme.colorScheme.onSurface,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Updates appear immediately while TREXVEN is connected.',
          style: TextStyle(fontSize: 13, color: muted),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: theme.trexvenColors.cardBackground,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            children: [_frequencyItem(theme, 'Instant'), _divider(theme)],
          ),
        ),
      ],
    );
  }

  Widget _frequencyItem(ThemeData theme, String value) {
    return RadioListTile<String>(
      value: value,
      groupValue: _frequency,
      activeColor: theme.colorScheme.primary,
      onChanged: _saving
          ? null
          : (selected) {
              if (selected != null) {
                _updateFrequency(selected);
              }
            },
      title: Text(
        value,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
          color: theme.colorScheme.onSurface,
        ),
      ),
    );
  }

  Widget _section(ThemeData theme, String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: theme.colorScheme.onSurface,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: theme.trexvenColors.cardBackground,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }

  Widget _divider(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.only(left: 72),
      child: Divider(
        height: 1,
        color: theme.trexvenColors.border?.withOpacity(0.5) ?? Colors.white12,
      ),
    );
  }

  Widget _item(
    ThemeData theme, {
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    final brandBlue = theme.colorScheme.primary;
    final muted = theme.trexvenColors.muted ?? Colors.grey;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: brandBlue.withOpacity(0.08),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(icon, color: brandBlue, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(fontSize: 12, color: muted, height: 1.4),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Switch(
            value: value,
            activeColor: brandBlue,
            onChanged: _saving ? null : onChanged,
          ),
        ],
      ),
    );
  }
}
