import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:trexven_operations/trexven_operations.dart';
import '../../services/database_service.dart';
import '../../core/app_sizing.dart';
import '../../models/subscription_plan.dart';

/// Canonical destination: Me → Manage Subscription → Billing & Plans.
class BillingScreen extends StatefulWidget {
  const BillingScreen({super.key});
  @override
  State<BillingScreen> createState() => _BillingScreenState();
}

class _BillingScreenState extends State<BillingScreen> {
  OperationsClient? _api;
  List<SubscriptionPlan> _plans = [];
  List<Map<String, dynamic>> _history = [];
  Map<String, dynamic> _subscription = {};
  bool _loading = false, _busy = false;
  String? _error, _message;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final business = await DatabaseService().requireBusinessId();
      final api = OperationsClient(Supabase.instance.client, business);
      final plans = await Supabase.instance.client
          .from('subscription_plans')
          .select('id,name,price,currency,interval_months,features')
          .eq('active', true)
          .order('rank');
      final subscription = Map<String, dynamic>.from(
        await api.call('get_trexven_entitlements', {'p_business_id': business})
            as Map,
      );
      final history = await api.list('billing_payments');
      if (!mounted) return;
      setState(() {
        _api = api;
        _plans = plans.map(SubscriptionPlan.fromJson).toList();
        _subscription = subscription;
        _history = history;
      });
    } catch (error) {
      if (mounted)
        setState(
          () => _error = CustomerPresentation.error(
            error,
            fallback: 'We could not load your subscription. Please try again.',
          ),
        );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _cancel() async {
    if (_busy || _api == null || _subscription['configured'] != true) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Request cancellation?'),
        content: const Text(
          'We will record your cancellation request for review. Your plan remains unchanged until the request is processed.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Keep plan'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Request cancellation'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _busy = true);
    try {
      await _api!.call('request_trexven_subscription_change', {
        'p_business_id': _api!.businessId,
        'p_request_id': _api!.requestId(),
        'p_action': 'cancel',
        'p_plan_id': null,
      });
      if (mounted)
        setState(
          () => _message =
              'Your cancellation request has been received for review.',
        );
    } catch (error) {
      if (mounted)
        setState(
          () => _message = CustomerPresentation.error(
            error,
            fallback: 'We could not confirm your request. Please try again.',
          ),
        );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final configured = _subscription['configured'] == true;
    return Scaffold(
      appBar: AppBar(title: const Text('Billing & Plans')),
      body: SafeArea(
        top: false,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.cloud_off_outlined, size: 32),
                      const SizedBox(height: 12),
                      Text(_error!, textAlign: TextAlign.center),
                      TextButton(
                        onPressed: _load,
                        child: const Text('Try again'),
                      ),
                    ],
                  ),
                ),
              )
            : RefreshIndicator(
                onRefresh: _load,
                child: ListView(
                  padding: AppSizing.pagePadding,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.primary.withValues(alpha: .08),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Current plan',
                            style: theme.textTheme.labelLarge,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            configured
                                ? CustomerPresentation.label(
                                    _subscription['plan'],
                                  )
                                : 'No active subscription',
                            style: theme.textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          if (configured) ...[
                            const SizedBox(height: 4),
                            Text(
                              CustomerPresentation.label(
                                _subscription['status'],
                              ),
                            ),
                            if (_subscription['renews_at'] != null)
                              Text(
                                'Renews ${CustomerPresentation.date(_subscription['renews_at'])}',
                              ),
                            if (_subscription['expires_at'] != null)
                              Text(
                                'Valid until ${CustomerPresentation.date(_subscription['expires_at'])}',
                              ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'Plans for your business',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Plan upgrades are not available yet.',
                      style: theme.textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 12),
                    for (final plan in _plans)
                      BillingPlanCard(
                        plan: plan,
                        current:
                            configured &&
                            _subscription['plan'] == plan.tier.name,
                      ),
                    if (_plans.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 16),
                        child: Text(
                          'Plan information is currently unavailable.',
                        ),
                      ),
                    if (_message != null)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: Text(_message!),
                      ),
                    if (configured &&
                        ![
                          'canceled',
                          'expired',
                        ].contains(_subscription['status']))
                      TextButton(
                        onPressed: _busy ? null : _cancel,
                        child: Text(
                          _busy ? 'Sending request…' : 'Request cancellation',
                        ),
                      ),
                    const SizedBox(height: 16),
                    Text('Billing history', style: theme.textTheme.titleMedium),
                    if (_history.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Text('No billing payments yet.'),
                      ),
                    for (final payment in _history)
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(
                          CustomerPresentation.money(
                            num.tryParse('${payment['amount']}') ?? 0,
                            currency: payment['currency'] as String?,
                          ),
                        ),
                        subtitle: Text(
                          CustomerPresentation.date(
                            payment['verified_at'],
                            includeTime: true,
                          ),
                        ),
                        trailing: Text(
                          CustomerPresentation.label(payment['status']),
                        ),
                      ),
                    if (_api != null)
                      TextButton(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AccountOperationsScreen(api: _api!),
                          ),
                        ),
                        child: const Text('Account requests and recovery'),
                      ),
                  ],
                ),
              ),
      ),
    );
  }
}

class BillingPlanCard extends StatelessWidget {
  final SubscriptionPlan plan;
  final bool current;
  const BillingPlanCard({super.key, required this.plan, this.current = false});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 0,
      color: current
          ? theme.colorScheme.primary.withValues(alpha: .08)
          : theme.colorScheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 12,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Text(
                  plan.name.toUpperCase(),
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
                if (current)
                  Chip(
                    label: const Text('Current plan'),
                    side: BorderSide.none,
                    visualDensity: VisualDensity.compact,
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(plan.description, style: theme.textTheme.bodySmall),
            if (plan.price != null &&
                plan.currency != null &&
                plan.intervalMonths != null) ...[
              const SizedBox(height: 8),
              Text(plan.priceDisplay, style: theme.textTheme.bodyMedium),
            ],
            const SizedBox(height: 10),
            for (final feature in plan.features)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.check_rounded,
                      size: 18,
                      color: theme.colorScheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(feature, style: theme.textTheme.bodySmall),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 10),
            const TextButton(
              onPressed: null,
              child: Text('Upgrades unavailable'),
            ),
          ],
        ),
      ),
    );
  }
}
