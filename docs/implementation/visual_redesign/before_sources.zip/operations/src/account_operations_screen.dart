import 'package:trexven_design_system/trexven_design_system.dart';
import 'customer_presentation.dart';
import 'package:flutter/material.dart';
import 'operations_client.dart';

class AccountOperationsScreen extends StatefulWidget {
  final OperationsClient api;
  const AccountOperationsScreen({super.key, required this.api});
  @override
  State<AccountOperationsScreen> createState() =>
      _AccountOperationsScreenState();
}

class _AccountOperationsScreenState extends State<AccountOperationsScreen> {
  late Future<Map<String, dynamic>> health;
  late Future<List<Map<String, dynamic>>> requests;
  bool busy = false;
  String? message;
  @override
  void initState() {
    super.initState();
    load();
  }

  void load() {
    health = widget.api
        .call('get_trexven_operational_health', {
          'p_business_id': widget.api.businessId,
        })
        .then((v) => Map<String, dynamic>.from(v as Map));
    requests = widget.api.list('account_lifecycle_requests');
  }

  Future<void> request(String kind) async {
    final reason = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        scrollable: true,
        title: Text('Request account $kind'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Your request will be reviewed. Your business records and pending sales will be kept safe.',
            ),
            TrexvenTextField(
              controller: reason,
              decoration: TrexvenInputDecoration(labelText: 'Reason'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Submit request'),
          ),
        ],
      ),
    );
    final text = reason.text.trim();
    reason.dispose();
    if (confirmed != true) return;
    setState(() => busy = true);
    try {
      await widget.api.call('request_trexven_account_lifecycle', {
        'p_business_id': widget.api.businessId,
        'p_request_id': widget.api.requestId(),
        'p_kind': kind,
        'p_reason': text,
      });
      if (mounted)
        setState(() {
          message = 'Owner request recorded. No records were deleted.';
          load();
        });
    } catch (e) {
      if (mounted)
        setState(
          () => message = CustomerPresentation.error(
            e,
            fallback: 'Request not confirmed. Please try again.',
          ),
        );
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Account and recovery')),
    body: ListView(
      padding: TrexvenSpacing.cardPadding,
      children: [
        if (message != null) Text(message!),
        if (busy) LinearProgressIndicator(),
        Wrap(
          spacing: 8,
          children: [
            for (final kind in ['recovery', 'deletion'])
              OutlinedButton(
                onPressed: busy ? null : () => request(kind),
                child: Text('Request $kind'),
              ),
          ],
        ),
        FutureBuilder<Map<String, dynamic>>(
          future: health,
          builder: (context, snapshot) {
            if (snapshot.hasError)
              return Text('Operational status unavailable.');
            if (!snapshot.hasData) return LinearProgressIndicator();
            final h = snapshot.data!, backup = h['latest_backup'] as Map?;
            return Text(
              backup == null
                  ? 'Recovery information is not available yet. Contact support if you need help.'
                  : 'Backup: ${CustomerPresentation.label(backup['status'])}\nSaved ${CustomerPresentation.date(backup['captured_at'], includeTime: true)}',
            );
          },
        ),
        FutureBuilder<List<Map<String, dynamic>>>(
          future: requests,
          builder: (context, snapshot) => Column(
            children: [
              for (final r in snapshot.data ?? <Map<String, dynamic>>[])
                ListTile(
                  title: Text(
                    '${CustomerPresentation.label(r['kind'])} · ${CustomerPresentation.label(r['status'])}',
                  ),
                  subtitle: Text('${r['created_at']} · ${r['reason']}'),
                ),
            ],
          ),
        ),
      ],
    ),
  );
}
