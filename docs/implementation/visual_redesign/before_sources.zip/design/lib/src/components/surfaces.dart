import 'package:flutter/material.dart';
import '../theme/tokens.dart';

class TrexvenCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const TrexvenCard({
    super.key,
    required this.child,
    this.padding = TrexvenSpacing.cardPadding,
  });
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(padding: padding, child: child),
  );
}

class TrexvenDialog extends StatelessWidget {
  final Widget? title, content;
  final List<Widget>? actions;
  const TrexvenDialog({super.key, this.title, this.content, this.actions});
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: title,
    scrollable: true,
    content: content,
    actions: actions,
  );
}

class TrexvenBottomSheet extends StatelessWidget {
  final Widget child;
  const TrexvenBottomSheet({super.key, required this.child});
  @override
  Widget build(BuildContext context) => SafeArea(
    child: SingleChildScrollView(
      padding: TrexvenSpacing.pagePadding.add(
        EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
      ),
      child: child,
    ),
  );
}

class TrexvenLoading extends StatelessWidget {
  final String? message;
  const TrexvenLoading({super.key, this.message});
  @override
  Widget build(BuildContext context) => Padding(
    padding: TrexvenSpacing.cardPadding,
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
        if (message != null) ...[
          const SizedBox(height: 16),
          Text(message!, textAlign: TextAlign.center),
        ],
      ],
    ),
  );
}

class TrexvenEmptyState extends StatelessWidget {
  final String title;
  final String? message;
  final IconData icon;
  final Widget? action;
  const TrexvenEmptyState({
    super.key,
    required this.title,
    this.message,
    this.icon = Icons.inbox_outlined,
    this.action,
  });
  @override
  Widget build(BuildContext context) => Padding(
    padding: TrexvenSpacing.pagePadding,
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 32, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 16),
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge,
          textAlign: TextAlign.center,
        ),
        if (message != null) ...[
          const SizedBox(height: 8),
          Text(message!, textAlign: TextAlign.center),
        ],
        if (action != null) ...[const SizedBox(height: 16), action!],
      ],
    ),
  );
}

class TrexvenErrorState extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  const TrexvenErrorState({super.key, required this.message, this.onRetry});
  @override
  Widget build(BuildContext context) => TrexvenEmptyState(
    title: 'Unable to load',
    message: message,
    icon: Icons.error_outline,
    action: onRetry == null
        ? null
        : TextButton(onPressed: onRetry, child: const Text('Retry')),
  );
}
