import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../models/sale.dart';
import '../auth/auth_provider.dart';
import 'sales_provider.dart';

class RecentSalesScreen extends ConsumerWidget {
  const RecentSalesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final employeeId =
        ref.watch(authStateProvider).employee?.membershipId ?? '';

    if (employeeId.trim().isEmpty) {
      return Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        appBar: _buildAppBar(context),
        body: _buildNoEmployeeState(context),
      );
    }

    final salesAsync = ref.watch(recentSalesProvider(employeeId));

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: _buildAppBar(context),
      body: salesAsync.when(
        data: (sales) => _buildSalesList(context, ref, employeeId, sales),
        loading: () => _buildLoadingState(context),
        error: (error, stackTrace) =>
            _buildErrorState(context, ref, employeeId),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      titleSpacing: 0,
      iconTheme: IconThemeData(color: Theme.of(context).colorScheme.onSurface),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Sale History',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface,
              fontSize: TrexvenFontSize.section,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.3,
            ),
          ),
          SizedBox(height: 2),
          Text(
            'Authorized business transactions',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              fontSize: TrexvenFontSize.caption,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSalesList(
    BuildContext context,
    WidgetRef ref,
    String employeeId,
    List<Sale> sales,
  ) {
    if (sales.isEmpty) {
      return RefreshIndicator(
        color: Theme.of(context).colorScheme.primary,
        onRefresh: () async {
          ref.invalidate(recentSalesProvider(employeeId));

          await ref.read(recentSalesProvider(employeeId).future);
        },
        child: ListView(
          physics: AlwaysScrollableScrollPhysics(),
          children: [SizedBox(height: 500, child: _buildEmptyState(context))],
        ),
      );
    }

    return RefreshIndicator(
      color: Theme.of(context).colorScheme.primary,
      onRefresh: () async {
        ref.invalidate(recentSalesProvider(employeeId));

        await ref.read(recentSalesProvider(employeeId).future);
      },
      child: ListView(
        physics: AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          _buildSummaryCard(context, sales),

          SizedBox(height: TrexvenSpacing.sectionGap),

          Text(
            'Recent Transactions',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface,
              fontSize: TrexvenFontSize.section,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.2,
            ),
          ),

          SizedBox(height: 12),

          ...sales.map((sale) => _buildSaleCard(context: context, sale: sale)),
        ],
      ),
    );
  }

  Widget _buildSummaryCard(BuildContext context, List<Sale> sales) {
    final totalSales = sales.fold<double>(0.0, (sum, sale) => sum + sale.total);

    final transactionCount = sales.length;

    return Container(
      padding: EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary,
        borderRadius: BorderRadius.circular(TrexvenRadii.card),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: Theme.of(
                context,
              ).colorScheme.onPrimary.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(TrexvenRadii.card),
            ),
            child: Icon(
              Icons.receipt_long_outlined,
              color: Theme.of(context).colorScheme.onPrimary,
              size: 26,
            ),
          ),
          SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Recent sales total',
                  style: TextStyle(
                    color: Theme.of(
                      context,
                    ).colorScheme.onPrimary.withValues(alpha: .7),
                    fontSize: TrexvenFontSize.caption,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  _formatCurrency(totalSales),
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onPrimary,
                    fontSize: TrexvenFontSize.section,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.4,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  '$transactionCount transaction${transactionCount == 1 ? '' : 's'}',
                  style: TextStyle(
                    color: Theme.of(
                      context,
                    ).colorScheme.onPrimary.withValues(alpha: .7),
                    fontSize: TrexvenFontSize.caption,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSaleCard({required BuildContext context, required Sale sale}) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(TrexvenRadii.card),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(TrexvenRadii.card),
          onTap: () => _showDetails(context, sale),
          child: Padding(
            padding: TrexvenSpacing.cardPadding,
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: Theme.of(
                      context,
                    ).colorScheme.primary.withValues(alpha: .08),
                    borderRadius: BorderRadius.circular(TrexvenRadii.card),
                  ),
                  child: Icon(
                    Icons.receipt_outlined,
                    color: Theme.of(context).colorScheme.primary,
                    size: 22,
                  ),
                ),
                SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _formatDate(sale.timestamp),
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onSurface,
                          fontSize: TrexvenFontSize.input,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 4),
                      Row(
                        children: [
                          Text(
                            _formatTime(sale.timestamp),
                            style: TextStyle(
                              color: Theme.of(
                                context,
                              ).colorScheme.onSurfaceVariant,
                              fontSize: TrexvenFontSize.caption,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 6),
                            child: Text(
                              '•',
                              style: TextStyle(
                                color: Theme.of(
                                  context,
                                ).colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ),
                          Expanded(
                            child: Text(
                              _formatPaymentMethod(sale.paymentMethod),
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Theme.of(
                                  context,
                                ).colorScheme.onSurfaceVariant,
                                fontSize: TrexvenFontSize.caption,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      _formatCurrency(sale.total),
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurface,
                        fontSize: TrexvenFontSize.input,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 4),
                    Icon(
                      Icons.chevron_right_rounded,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      size: 20,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingState(BuildContext context) {
    return Center(
      child: CircularProgressIndicator(
        color: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.primary.withValues(alpha: .08),
                borderRadius: BorderRadius.circular(TrexvenRadii.card),
              ),
              child: Icon(
                Icons.receipt_long_outlined,
                color: Theme.of(context).colorScheme.primary,
                size: 34,
              ),
            ),
            SizedBox(height: TrexvenSpacing.fieldGap),
            Text(
              'No sales yet',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurface,
                fontSize: TrexvenFontSize.section,
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(height: 7),
            Text(
              'Completed sales will appear here.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontSize: TrexvenFontSize.body,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoEmployeeState(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.primary.withValues(alpha: .08),
                borderRadius: BorderRadius.circular(TrexvenRadii.card),
              ),
              child: Icon(
                Icons.person_off_outlined,
                color: Theme.of(context).colorScheme.primary,
                size: 34,
              ),
            ),
            SizedBox(height: TrexvenSpacing.fieldGap),
            Text(
              'Employee not available',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurface,
                fontSize: TrexvenFontSize.section,
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(height: 7),
            Text(
              'Please sign in again to view your sale history.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontSize: TrexvenFontSize.body,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState(
    BuildContext context,
    WidgetRef ref,
    String employeeId,
  ) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.error.withValues(alpha: .08),
                borderRadius: BorderRadius.circular(TrexvenRadii.card),
              ),
              child: Icon(
                Icons.error_outline_rounded,
                color: Theme.of(context).colorScheme.error,
                size: 34,
              ),
            ),
            SizedBox(height: TrexvenSpacing.fieldGap),
            Text(
              'Unable to load sales',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurface,
                fontSize: TrexvenFontSize.section,
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(height: 7),
            Text(
              'Check your connection and try again.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontSize: TrexvenFontSize.body,
              ),
            ),
            SizedBox(height: TrexvenSpacing.fieldGap),
            ElevatedButton(
              onPressed: () {
                ref.invalidate(recentSalesProvider(employeeId));
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Theme.of(context).colorScheme.onPrimary,
              ),
              child: Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  void _showDetails(BuildContext context, Sale sale) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.75,
          minChildSize: 0.5,
          maxChildSize: 0.95,
          builder: (context, scrollController) {
            return Container(
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: Column(
                children: [
                  SizedBox(height: 10),
                  Container(
                    width: 38,
                    height: 5,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.outlineVariant,
                      borderRadius: BorderRadius.circular(TrexvenRadii.card),
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      controller: scrollController,
                      padding: EdgeInsets.fromLTRB(16, 20, 16, 32),
                      children: [
                        Text(
                          'Sale Details',
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.onSurface,
                            fontSize: TrexvenFontSize.title,
                            fontWeight: FontWeight.w700,
                            letterSpacing: -0.5,
                          ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          DateFormat(
                            'MMMM dd, yyyy • HH:mm',
                          ).format(sale.timestamp),
                          style: TextStyle(
                            color: Theme.of(
                              context,
                            ).colorScheme.onSurfaceVariant,
                            fontSize: TrexvenFontSize.body,
                          ),
                        ),
                        SizedBox(height: TrexvenSpacing.fieldGap),
                        _buildDetailsSummary(context, sale),
                        SizedBox(height: TrexvenSpacing.sectionGap),
                        Text(
                          'Items Sold',
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.onSurface,
                            fontSize: TrexvenFontSize.section,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        SizedBox(height: 12),
                        ...sale.items.asMap().entries.map(
                          (entry) => _buildSaleItemCard(
                            context,
                            entry.key,
                            entry.value,
                          ),
                        ),
                        SizedBox(height: 12),
                        _buildTotalCard(context, sale),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildDetailsSummary(BuildContext context, Sale sale) {
    final totalQuantity = sale.items.fold<num>(
      0,
      (sum, item) => sum + item.quantity,
    );

    return Container(
      padding: TrexvenSpacing.cardPadding,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(TrexvenRadii.card),
      ),
      child: Column(
        children: [
          _buildSummaryRow(
            context,
            icon: Icons.payments_outlined,
            label: 'Payment Method',
            value: _formatPaymentMethod(sale.paymentMethod),
          ),
          Divider(
            height: 24,
            color: Theme.of(context).colorScheme.outlineVariant,
          ),
          _buildSummaryRow(
            context,
            icon: Icons.shopping_bag_outlined,
            label: 'Items',
            value: '$totalQuantity item${totalQuantity == 1 ? '' : 's'}',
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withValues(alpha: .08),
            borderRadius: BorderRadius.circular(TrexvenRadii.card),
          ),
          child: Icon(
            icon,
            color: Theme.of(context).colorScheme.primary,
            size: 19,
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              fontSize: TrexvenFontSize.body,
            ),
          ),
        ),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface,
              fontSize: TrexvenFontSize.body,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSaleItemCard(BuildContext context, int index, SaleItem item) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(TrexvenRadii.card),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Theme.of(
                context,
              ).colorScheme.primary.withValues(alpha: .08),
              borderRadius: BorderRadius.circular(TrexvenRadii.card),
            ),
            child: Center(
              child: Text(
                '${index + 1}',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.primary,
                  fontSize: TrexvenFontSize.input,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _formatPriceLevel(item.priceLevel),
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurface,
                    fontSize: TrexvenFontSize.body,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  '${item.quantity} × ${_formatCurrency(item.unitPrice)}',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    fontSize: TrexvenFontSize.caption,
                  ),
                ),
              ],
            ),
          ),
          Text(
            _formatCurrency(item.total),
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface,
              fontSize: TrexvenFontSize.input,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTotalCard(BuildContext context, Sale sale) {
    return Container(
      padding: EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary,
        borderRadius: BorderRadius.circular(TrexvenRadii.card),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Total Amount',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onPrimary,
              fontSize: TrexvenFontSize.section,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            _formatCurrency(sale.total),
            style: TextStyle(
              color: Theme.of(context).colorScheme.onPrimary,
              fontSize: TrexvenFontSize.section,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  String _formatCurrency(double amount) {
    return NumberFormat.currency(
      locale: 'en_NG',
      symbol: '₦',
      decimalDigits: 2,
    ).format(amount);
  }

  String _formatDate(DateTime date) {
    return DateFormat('MMM dd, yyyy').format(date);
  }

  String _formatTime(DateTime date) {
    return DateFormat('HH:mm').format(date);
  }

  String _formatPaymentMethod(String method) {
    if (method.trim().isEmpty) {
      return 'Unknown';
    }

    return method
        .split('_')
        .map(
          (word) => word.isEmpty
              ? ''
              : '${word[0].toUpperCase()}${word.substring(1)}',
        )
        .join(' ');
  }

  String _formatPriceLevel(String level) {
    if (level.trim().isEmpty) {
      return 'Standard';
    }

    return level
        .split('_')
        .map(
          (word) => word.isEmpty
              ? ''
              : '${word[0].toUpperCase()}${word.substring(1)}',
        )
        .join(' ');
  }
}
