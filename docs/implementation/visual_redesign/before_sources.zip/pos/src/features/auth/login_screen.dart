import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'auth_provider.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _employeeIdController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _ownerLogin = false;

  @override
  void dispose() {
    _employeeIdController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authStateProvider);

    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: TrexvenSpacing.pagePadding,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Logo and Branding
              Column(
                children: [
                  Image.asset('assets/trexvenpos_logo.png', height: 100),
                  SizedBox(height: TrexvenSpacing.sectionGap),
                  Text(
                    'Trexven POS',
                    style: TextStyle(
                      fontSize: TrexvenFontSize.display,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text('Operational terminal for businesses'),
                ],
              ),
              SizedBox(height: 48),

              // Login Form Card
              Card(
                child: Container(
                  constraints: BoxConstraints(maxWidth: 400),
                  padding: TrexvenSpacing.pagePadding,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'Sign In',
                        style: TextStyle(
                          fontSize: TrexvenFontSize.title,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: TrexvenSpacing.sectionGap),
                      SwitchListTile(
                        title: Text('Business owner sign-in'),
                        value: _ownerLogin,
                        onChanged: authState.isLoading
                            ? null
                            : (value) => setState(() => _ownerLogin = value),
                      ),
                      for (final context in authState.contexts)
                        if (authState.employee == null)
                          ListTile(
                            title: Text(
                              (context['business'] as Map)['business_name']
                                  as String,
                            ),
                            onTap: () => ref
                                .read(authStateProvider.notifier)
                                .restoreSession(
                                  businessId:
                                      (context['business'] as Map)['id']
                                          as String,
                                ),
                          ),
                      TrexvenTextField(
                        controller: _employeeIdController,
                        enabled: !authState.isLoading,
                        keyboardType: _ownerLogin
                            ? TextInputType.emailAddress
                            : TextInputType.text,
                        autocorrect: false,
                        autofillHints: [
                          _ownerLogin
                              ? AutofillHints.email
                              : AutofillHints.username,
                        ],
                        decoration: TrexvenInputDecoration(
                          labelText: _ownerLogin
                              ? 'Owner email'
                              : 'Employee ID',
                          prefixIcon: Icon(Icons.person_outline),
                        ),
                      ),
                      TrexvenTextField(
                        controller: _passwordController,
                        enabled: !authState.isLoading,
                        obscureText: true,
                        autocorrect: false,
                        enableSuggestions: false,
                        autofillHints: [AutofillHints.password],
                        decoration: TrexvenInputDecoration(
                          labelText: 'Password / PIN',
                          prefixIcon: Icon(Icons.lock_outline),
                        ),
                      ),
                      SizedBox(height: TrexvenSpacing.sectionGap),
                      if (authState.error != null)
                        Padding(
                          padding: EdgeInsets.only(bottom: 16.0),
                          child: Text(
                            authState.error!,
                            style: TextStyle(
                              color: Theme.of(context).colorScheme.error,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ElevatedButton(
                        onPressed: authState.isLoading
                            ? null
                            : () {
                                final auth = ref.read(
                                  authStateProvider.notifier,
                                );
                                if (_ownerLogin) {
                                  auth.loginOwner(
                                    _employeeIdController.text,
                                    _passwordController.text,
                                  );
                                } else {
                                  auth.login(
                                    _employeeIdController.text,
                                    _passwordController.text,
                                  );
                                }
                              },
                        child: authState.isLoading
                            ? CircularProgressIndicator()
                            : Text('Login'),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 48),
              Text('© 2026 ODT Web Ecosystem'),
            ],
          ),
        ),
      ),
    );
  }
}
