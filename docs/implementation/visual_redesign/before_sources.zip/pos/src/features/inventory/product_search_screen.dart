import 'package:trexven_design_system/trexven_design_system.dart';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/product.dart';
import 'product_detail_screen.dart';
import 'product_provider.dart';

class ProductSearchScreen extends ConsumerStatefulWidget {
  const ProductSearchScreen({super.key});

  @override
  ConsumerState<ProductSearchScreen> createState() =>
      _ProductSearchScreenState();
}

class _ProductSearchScreenState extends ConsumerState<ProductSearchScreen> {
  final _searchController = TextEditingController();

  String _query = '';
  Timer? _debounce;

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged(String value) {
    // Rebuild immediately so the clear button responds instantly.
    setState(() {});

    _debounce?.cancel();

    _debounce = Timer(Duration(milliseconds: 300), () {
      if (!mounted) return;

      setState(() {
        _query = value.trim();
      });
    });
  }

  void _clearSearch() {
    _debounce?.cancel();

    setState(() {
      _searchController.clear();
      _query = '';
    });
  }

  Future<void> _refresh() async {
    if (_query.isEmpty) return;

    ref.invalidate(productSearchProvider(_query));
  }

  @override
  Widget build(BuildContext context) {
    final searchResult = ref.watch(productSearchProvider(_query));
    final isSearching = _query.isNotEmpty;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Apple-inspired large navigation title.
            Padding(
              padding: EdgeInsets.fromLTRB(16, 18, 16, 12),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Search',
                  style: TextStyle(
                    fontSize: TrexvenFontSize.display,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.8,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
              ),
            ),

            // Search field.
            Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: Container(
                constraints: BoxConstraints(minHeight: 48),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(TrexvenRadii.card),
                ),
                child: TrexvenTextField(
                  variant: TrexvenFieldVariant.search,
                  gap: 0,
                  controller: _searchController,
                  autofocus: true,
                  onChanged: _onSearchChanged,
                  textInputAction: TextInputAction.search,
                  decoration: TrexvenInputDecoration(
                    hintText: 'Products, barcode, part number',
                    prefixIcon: Icon(
                      Icons.search_rounded,
                      size: 22,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                            onPressed: _clearSearch,
                            icon: Icon(
                              Icons.cancel_rounded,
                              size: 20,
                              color: Theme.of(
                                context,
                              ).colorScheme.onSurfaceVariant,
                            ),
                          )
                        : null,
                  ),
                ),
              ),
            ),

            Expanded(
              child: AnimatedSwitcher(
                duration: Duration(milliseconds: 200),
                child: !isSearching
                    ? _buildInitialState()
                    : searchResult.when(
                        loading: _buildLoadingState,
                        error: (error, stackTrace) => _buildErrorState(),
                        data: (products) {
                          if (products.isEmpty) {
                            return _buildNoResultsState();
                          }

                          return RefreshIndicator(
                            color: Theme.of(context).colorScheme.primary,
                            onRefresh: _refresh,
                            child: ListView(
                              key: ValueKey('search-results'),
                              physics: AlwaysScrollableScrollPhysics(),
                              padding: EdgeInsets.fromLTRB(16, 4, 16, 32),
                              children: [
                                Padding(
                                  padding: EdgeInsets.fromLTRB(4, 8, 4, 10),
                                  child: Text(
                                    '${products.length} ${products.length == 1 ? 'Result' : 'Results'}',
                                    style: TextStyle(
                                      fontSize: TrexvenFontSize.body,
                                      fontWeight: FontWeight.w500,
                                      color: Theme.of(
                                        context,
                                      ).colorScheme.onSurfaceVariant,
                                    ),
                                  ),
                                ),

                                // Grouped results.
                                Container(
                                  clipBehavior: Clip.antiAlias,
                                  decoration: BoxDecoration(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.onPrimary,
                                    borderRadius: BorderRadius.circular(
                                      TrexvenRadii.card,
                                    ),
                                  ),
                                  child: Column(
                                    children: [
                                      for (
                                        int index = 0;
                                        index < products.length;
                                        index++
                                      ) ...[
                                        _buildProductRow(products[index]),

                                        if (index != products.length - 1)
                                          Padding(
                                            padding: EdgeInsets.only(left: 82),
                                            child: Divider(
                                              height: 1,
                                              thickness: 0.7,
                                              color: Theme.of(
                                                context,
                                              ).colorScheme.outlineVariant,
                                            ),
                                          ),
                                      ],
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInitialState() {
    return Center(
      key: ValueKey('initial'),
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.search_rounded,
                size: 52,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              SizedBox(height: TrexvenSpacing.fieldGap),
              Text(
                'Search your inventory',
                style: TextStyle(
                  fontSize: TrexvenFontSize.section,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.3,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Find products by name, barcode, part number, or brand.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: TrexvenFontSize.input,
                  height: 1.4,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      key: ValueKey('loading'),
      child: CircularProgressIndicator(
        strokeWidth: 2.5,
        color: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  Widget _buildNoResultsState() {
    return Center(
      key: ValueKey('no-results'),
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.inventory_2_outlined,
                size: 52,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              SizedBox(height: TrexvenSpacing.fieldGap),
              Text(
                'No Results',
                style: TextStyle(
                  fontSize: TrexvenFontSize.section,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.4,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'No products match "$_query".',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: TrexvenFontSize.input,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
              SizedBox(height: TrexvenSpacing.fieldGap),
              TextButton(
                onPressed: _clearSearch,
                child: Text(
                  'Clear Search',
                  style: TextStyle(
                    fontSize: TrexvenFontSize.input,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      key: ValueKey('error'),
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.error_outline_rounded,
                size: 52,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              SizedBox(height: TrexvenSpacing.fieldGap),
              Text(
                'Search Unavailable',
                style: TextStyle(
                  fontSize: TrexvenFontSize.section,
                  fontWeight: FontWeight.w700,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Something went wrong. Please try again.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: TrexvenFontSize.input,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
              SizedBox(height: TrexvenSpacing.fieldGap),
              TextButton(
                onPressed: () {
                  ref.invalidate(productSearchProvider(_query));
                },
                child: Text(
                  'Try Again',
                  style: TextStyle(
                    fontSize: TrexvenFontSize.input,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProductRow(Product product) {
    final brand = product.brand?.trim();
    final partNumber = product.partNumber?.trim();
    final barcode = product.barcode?.trim();

    return Material(
      color: Theme.of(context).colorScheme.onPrimary,
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ProductDetailScreen(product: product),
            ),
          );
        },
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: Theme.of(
                    context,
                  ).colorScheme.primary.withValues(alpha: .08),
                  borderRadius: BorderRadius.circular(TrexvenRadii.card),
                ),
                child: Icon(
                  Icons.inventory_2_outlined,
                  size: 24,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),

              SizedBox(width: 14),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: TrexvenFontSize.input,
                        fontWeight: FontWeight.w600,
                        letterSpacing: -0.2,
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                    ),

                    SizedBox(height: 4),

                    if (brand != null && brand.isNotEmpty)
                      Text(
                        brand,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: TrexvenFontSize.body,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),

                    if (partNumber != null && partNumber.isNotEmpty)
                      Padding(
                        padding: EdgeInsets.only(top: 3),
                        child: Text(
                          'Part #$partNumber',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: TrexvenFontSize.caption,
                            color: Theme.of(
                              context,
                            ).colorScheme.onSurfaceVariant,
                          ),
                        ),
                      )
                    else if (barcode != null && barcode.isNotEmpty)
                      Padding(
                        padding: EdgeInsets.only(top: 3),
                        child: Text(
                          barcode,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: TrexvenFontSize.caption,
                            color: Theme.of(
                              context,
                            ).colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                  ],
                ),
              ),

              SizedBox(width: 8),

              Icon(
                Icons.chevron_right_rounded,
                size: 22,
                color: Theme.of(context).colorScheme.outlineVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
