import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:trexven_operations/trexven_operations.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'login_screen.dart';
import '../../services/auth_service.dart';
import '../../widgets/google_sign_in_button.dart';
import '../me/terms_of_service_screen.dart';
import '../me/privacy_policy_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmController = TextEditingController();

  bool _obscurePassword = true;
  bool _obscureConfirm = true;
  bool _acceptedTerms = false;
  bool _loading = false;

  double get passwordStrength {
    final password = _passwordController.text;
    if (password.isEmpty) return 0;
    double strength = 0;
    if (password.length >= 8) strength += .25;
    if (RegExp(r'[A-Z]').hasMatch(password)) strength += .25;
    if (RegExp(r'[0-9]').hasMatch(password)) strength += .25;
    if (RegExp(r'[!@#$%^&*(),.?":{}|<>]').hasMatch(password)) {
      strength += .25;
    }
    return strength;
  }

  String get strengthText {
    if (passwordStrength <= .25) return 'Weak';
    if (passwordStrength <= .5) return 'Fair';
    if (passwordStrength <= .75) return 'Good';
    return 'Strong';
  }

  Color get strengthColor {
    final theme = Theme.of(context);
    if (passwordStrength <= .25) return theme.trexvenColors.error!;
    if (passwordStrength <= .5) return theme.trexvenColors.warning!;
    if (passwordStrength <= .75)
      return Theme.of(context).trexvenColors.warning!;
    return theme.trexvenColors.success!;
  }

  Future<void> _createAccount() async {
    if (!_formKey.currentState!.validate()) return;

    if (!_acceptedTerms) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Please agree to the Terms of Service and Privacy Policy.',
          ),
        ),
      );
      return;
    }

    setState(() => _loading = true);

    try {
      final email = _emailController.text.trim();
      final password = _passwordController.text;

      final response = await Supabase.instance.client.auth.signUp(
        email: email,
        password: password,
        emailRedirectTo: AuthService.redirectUrl,
        data: {
          'full_name': _nameController.text.trim(),
          'phone': _phoneController.text.trim(),
        },
      );

      if (!mounted) return;
      setState(() => _loading = false);

      final user = response.user;
      if (user == null) {
        _showError('Account could not be created. Please try again.');
        return;
      }

      if (response.session == null) {
        await _showEmailVerificationMessage(email);
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => LoginScreen()),
        );
        return;
      }

      // AccountGate handles the authenticated onboarding destination.
    } on AuthException catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      _showError(CustomerPresentation.error(error));
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      _showError(
        'Something went wrong while creating your account. Please try again.',
      );
    }
  }

  Future<void> _showEmailVerificationMessage(String email) async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          scrollable: true,
          title: Text('Check your email'),
          content: Text(
            'We sent a verification link to $email.\n\n'
            'Please verify your email address before signing in.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Continue'),
            ),
          ],
        );
      },
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _confirmController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.trexvenColors.muted!;
    final brandBlue = theme.colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: theme.colorScheme.onSurface),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'TREXVEN',
          style: TextStyle(
            fontWeight: FontWeight.w900,
            fontSize: TrexvenFontSize.input,
            letterSpacing: 1,
            color: theme.colorScheme.onSurface,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(16, 10, 16, 30),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Create your account',
                  style: TextStyle(
                    fontSize: TrexvenFontSize.display,
                    fontWeight: FontWeight.w800,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                SizedBox(height: 7),
                Text(
                  'Start by creating your secure owner account.',
                  style: TextStyle(
                    color: muted,
                    fontSize: TrexvenFontSize.body,
                  ),
                ),
                SizedBox(height: TrexvenSpacing.sectionGap),
                _field(
                  controller: _nameController,
                  hint: 'Full name',
                  icon: Icons.person_outline,
                  theme: theme,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter your full name.';
                    }
                    return null;
                  },
                ),
                _field(
                  controller: _emailController,
                  hint: 'Email address',
                  icon: Icons.mail_outline,
                  theme: theme,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter your email address.';
                    }
                    if (!RegExp(
                      r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
                    ).hasMatch(value.trim())) {
                      return 'Please enter a valid email address.';
                    }
                    return null;
                  },
                ),
                _field(
                  controller: _phoneController,
                  hint: 'Phone number',
                  icon: Icons.phone_outlined,
                  theme: theme,
                  keyboardType: TextInputType.phone,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter your phone number.';
                    }
                    return null;
                  },
                ),
                TrexvenTextFormField(
                  controller: _passwordController,
                  obscureText: _obscurePassword,
                  onChanged: (_) => setState(() {}),
                  decoration: TrexvenInputDecoration(
                    hintText: 'Password',
                    prefixIcon: Icon(Icons.lock_outline, color: muted),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscurePassword
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        color: muted,
                      ),
                      onPressed: () {
                        setState(() {
                          _obscurePassword = !_obscurePassword;
                        });
                      },
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.length < 8) {
                      return 'Password must contain at least 8 characters.';
                    }
                    return null;
                  },
                ),
                if (_passwordController.text.isNotEmpty) ...[
                  SizedBox(height: 9),
                  Row(
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(
                            TrexvenRadii.progress,
                          ),
                          child: LinearProgressIndicator(
                            value: passwordStrength,
                            minHeight: 6,
                            backgroundColor: theme.trexvenColors.border,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              strengthColor,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 10),
                      Text(
                        strengthText,
                        style: TextStyle(
                          color: strengthColor,
                          fontSize: TrexvenFontSize.caption,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ],
                SizedBox(height: TrexvenSpacing.fieldGap),
                TrexvenTextFormField(
                  controller: _confirmController,
                  obscureText: _obscureConfirm,
                  decoration: TrexvenInputDecoration(
                    hintText: 'Confirm password',
                    prefixIcon: Icon(Icons.lock_outline, color: muted),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscureConfirm
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        color: muted,
                      ),
                      onPressed: () {
                        setState(() {
                          _obscureConfirm = !_obscureConfirm;
                        });
                      },
                    ),
                  ),
                  validator: (value) {
                    if (value != _passwordController.text) {
                      return 'Passwords do not match.';
                    }
                    return null;
                  },
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Checkbox(
                      value: _acceptedTerms,
                      activeColor: brandBlue,
                      onChanged: (value) {
                        setState(() {
                          _acceptedTerms = value ?? false;
                        });
                      },
                    ),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(top: 12),
                        child: RichText(
                          text: TextSpan(
                            text: 'I agree to the ',
                            style: TextStyle(
                              fontSize: TrexvenFontSize.body,
                              height: 1.4,
                              color: muted,
                            ),
                            children: [
                              TextSpan(
                                text: 'Terms of Service',
                                style: TextStyle(
                                  color: brandBlue,
                                  fontWeight: FontWeight.w700,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => TermsOfServiceScreen(),
                                      ),
                                    );
                                  },
                              ),
                              TextSpan(
                                text: ' and ',
                                style: TextStyle(color: muted),
                              ),
                              TextSpan(
                                text: 'Privacy Policy',
                                style: TextStyle(
                                  color: brandBlue,
                                  fontWeight: FontWeight.w700,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => PrivacyPolicyScreen(),
                                      ),
                                    );
                                  },
                              ),
                              TextSpan(
                                text: '.',
                                style: TextStyle(color: muted),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: TrexvenSpacing.fieldGap),
                GoogleSignInButton(enabled: !_loading && _acceptedTerms),
                SizedBox(height: 12),
                ElevatedButton(
                  onPressed: _loading ? null : _createAccount,
                  child: _loading
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 19,
                              height: 19,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Theme.of(context).colorScheme.onPrimary,
                              ),
                            ),
                            SizedBox(width: 12),
                            Flexible(child: Text('Creating account...')),
                          ],
                        )
                      : Text('Create Account'),
                ),
                SizedBox(height: TrexvenSpacing.fieldGap),
                Wrap(
                  alignment: WrapAlignment.center,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(
                      'Already have an account? ',
                      style: TextStyle(
                        color: muted,
                        fontSize: TrexvenFontSize.body,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (_) => LoginScreen()),
                        );
                      },
                      child: Text(
                        'Sign In',
                        style: TextStyle(
                          color: brandBlue,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _field({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    required ThemeData theme,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return TrexvenTextFormField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: TrexvenInputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: theme.trexvenColors.muted),
      ),
      validator: validator,
    );
  }
}
