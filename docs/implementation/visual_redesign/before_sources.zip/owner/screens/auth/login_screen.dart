import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:trexven_operations/trexven_operations.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../widgets/trexven_logo.dart';
import 'forgot_password_screen.dart';
import 'register_screen.dart';
import '../../widgets/google_sign_in_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();

  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _obscurePassword = true;
  bool _rememberMe = false;
  bool _loading = false;

  Future<void> _signIn() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _loading = true);

    try {
      final email = _emailController.text.trim();
      final password = _passwordController.text;

      final response = await Supabase.instance.client.auth.signInWithPassword(
        email: email,
        password: password,
      );

      if (!mounted) return;

      final user = response.user;

      if (user == null) {
        setState(() => _loading = false);
        _showError('Unable to sign in. Please check your account details.');
        return;
      }

      if (user.emailConfirmedAt == null) {
        await Supabase.instance.client.auth.signOut();
        if (!mounted) return;
        setState(() => _loading = false);
        await _showEmailVerificationMessage(email);
        return;
      }

      // The app auth listener routes all successful sessions through AccountGate.
      if (mounted) setState(() => _loading = false);
    } on AuthException catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      _showError(_getAuthErrorMessage(error));
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      _showError('Something went wrong while signing in. Please try again.');
    }
  }

  String _getAuthErrorMessage(AuthException error) {
    final message = error.message.toLowerCase();
    if (message.contains('invalid login credentials')) {
      return 'Incorrect email or password.';
    }
    if (message.contains('email not confirmed')) {
      return 'Please verify your email address before signing in.';
    }
    if (message.contains('too many requests')) {
      return 'Too many attempts. Please wait a moment and try again.';
    }
    return CustomerPresentation.error(error);
  }

  Future<void> _showEmailVerificationMessage(String email) async {
    await showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          scrollable: true,
          title: Text('Email not verified'),
          content: Text(
            'Please verify your email address before signing in.\n\n'
            'We sent a verification link to:\n$email',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.trexvenColors.muted!;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: theme.colorScheme.onSurface),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: TrexvenSpacing.pagePadding,
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(child: TrexvenLogo(size: 62)),
                SizedBox(height: TrexvenSpacing.sectionGap),
                Text(
                  'Welcome back',
                  style: TextStyle(
                    fontSize: TrexvenFontSize.display,
                    fontWeight: FontWeight.w800,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                SizedBox(height: 7),
                Text(
                  'Sign in to securely access your business.',
                  style: TextStyle(
                    fontSize: TrexvenFontSize.body,
                    color: muted,
                  ),
                ),
                SizedBox(height: TrexvenSpacing.sectionGap),
                TrexvenTextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: TrexvenInputDecoration(
                    hintText: 'Email Address',
                    prefixIcon: Icon(Icons.mail_outline, color: muted),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter your email address.';
                    }
                    if (!RegExp(
                      r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
                    ).hasMatch(value.trim())) {
                      return 'Please enter a valid email address.';
                    }
                    return null;
                  },
                ),
                TrexvenTextFormField(
                  controller: _passwordController,
                  obscureText: _obscurePassword,
                  decoration: TrexvenInputDecoration(
                    hintText: 'Password',
                    prefixIcon: Icon(Icons.lock_outline, color: muted),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscurePassword
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        color: muted,
                      ),
                      onPressed: () {
                        setState(() {
                          _obscurePassword = !_obscurePassword;
                        });
                      },
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your password.';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Checkbox(
                      value: _rememberMe,
                      activeColor: theme.colorScheme.primary,
                      onChanged: (value) {
                        setState(() {
                          _rememberMe = value ?? false;
                        });
                      },
                    ),
                    Text(
                      'Remember me',
                      style: TextStyle(
                        color: muted,
                        fontSize: TrexvenFontSize.body,
                      ),
                    ),

                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ForgotPasswordScreen(),
                          ),
                        );
                      },
                      child: Text(
                        'Forgot password?',
                        style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.w700,
                          fontSize: TrexvenFontSize.body,
                        ),
                      ),
                    ),
                  ],
                ),
                GoogleSignInButton(enabled: !_loading),
                SizedBox(height: TrexvenSpacing.fieldGap),
                ElevatedButton(
                  onPressed: _loading ? null : _signIn,
                  child: _loading
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 19,
                              height: 19,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Theme.of(context).colorScheme.onPrimary,
                              ),
                            ),
                            SizedBox(width: 12),
                            Flexible(child: Text('Signing you in...')),
                          ],
                        )
                      : Text('Sign In'),
                ),
                SizedBox(height: 25),
                Row(
                  children: [
                    Expanded(
                      child: Divider(color: theme.trexvenColors.border!),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 14),
                      child: Text(
                        'OR',
                        style: TextStyle(
                          color: theme.trexvenColors.muted?.withValues(
                            alpha: 0.6,
                          ),
                          fontSize: TrexvenFontSize.caption,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Divider(color: theme.trexvenColors.border!),
                    ),
                  ],
                ),
                SizedBox(height: TrexvenSpacing.fieldGap),
                OutlinedButton.icon(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'Google sign-in isn\'t set up yet — use email and password for now.',
                        ),
                      ),
                    );
                  },
                  icon: Icon(Icons.g_mobiledata),
                  label: Text('Continue with Google'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: theme.colorScheme.onSurface,
                  ),
                ),
                SizedBox(height: TrexvenSpacing.sectionGap),
                Wrap(
                  alignment: WrapAlignment.center,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(
                      "Don't have an account? ",
                      style: TextStyle(
                        color: muted,
                        fontSize: TrexvenFontSize.body,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => RegisterScreen()),
                        );
                      },
                      child: Text(
                        'Create one',
                        style: TextStyle(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
