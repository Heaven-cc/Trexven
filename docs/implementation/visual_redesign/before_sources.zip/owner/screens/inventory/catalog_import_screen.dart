import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:trexven_operations/trexven_operations.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:file_selector/file_selector.dart';
import '../../services/catalog_import.dart';
import '../../services/database_service.dart';

class CatalogImportScreen extends StatefulWidget {
  const CatalogImportScreen({super.key, required this.database});
  final DatabaseService database;
  @override
  State<CatalogImportScreen> createState() => _CatalogImportScreenState();
}

class _CatalogImportScreenState extends State<CatalogImportScreen> {
  final _text = TextEditingController();
  final _request = Uuid().v4();
  List<Map<String, dynamic>>? _rows;
  String? _error;
  bool _busy = false;
  bool _submitted = false;
  bool _updateExisting = false;
  List<Map<String, dynamic>>? _fileRows;
  String? _fileName;
  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  String _importValidation(String message) {
    const labels = {
      'stock_delta': 'stock change',
      'stock_reason': 'stock change reason',
      'initial_quantity': 'opening quantity',
      'selling_price': 'selling price',
      'low_stock_threshold': 'low-stock threshold',
      'image_url': 'image link',
      'group_name': 'product group',
    };
    for (final entry in labels.entries) {
      message = message.replaceAll(entry.key, entry.value);
    }
    return message;
  }

  Future<void> _review() async {
    if (_busy || _submitted) return;
    setState(() => _busy = true);
    try {
      final rows = (_fileRows ?? CatalogImport.parse(_text.text))
          .map((r) => Map<String, dynamic>.from(r))
          .toList();
      final products = await widget.database.getProducts();
      for (final row in rows) {
        final matches = products
            .where(
              (p) =>
                  (row['barcode'] != null &&
                      p.barcode?.trim() == row['barcode']) ||
                  (row['sku'] != null && p.sku?.trim() == row['sku']),
            )
            .toList();
        if (matches.length > 1) {
          throw FormatException('Ambiguous barcode/SKU for ${row['name']}.');
        }
        if (matches.isNotEmpty) {
          if (!_updateExisting) {
            throw FormatException(
              'Existing barcode/SKU for ${row['name']}. Enable reviewed updates or edit separately.',
            );
          }
          if (row.containsKey('initial_quantity')) {
            throw FormatException(
              'Use stock_delta and stock_reason when updating ${row['name']}.',
            );
          }
          row['product_id'] = matches.single.id;
        } else if (row.containsKey('stock_delta')) {
          throw FormatException(
            'Use initial_quantity for new product ${row['name']}.',
          );
        }
      }
      if (mounted) {
        setState(() {
          _rows = rows;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e is FormatException
              ? _importValidation(e.message)
              : CustomerPresentation.error(
                  e,
                  fallback:
                      'We could not review this import. Please try again.',
                );
          _rows = null;
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _chooseFile() async {
    try {
      final file = await openFile(
        acceptedTypeGroups: [
          XTypeGroup(
            label: 'Product CSV or Excel',
            extensions: ['csv', 'xlsx'],
            mimeTypes: [
              'text/csv',
              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            ],
            uniformTypeIdentifiers: [
              'public.comma-separated-values-text',
              'org.openxmlformats.spreadsheetml.sheet',
            ],
          ),
        ],
      );
      if (file == null) return;
      if (file.name.toLowerCase().endsWith('.xlsx')) {
        _fileRows = CatalogImport.parseExcel(await file.readAsBytes());
        _text.clear();
      } else {
        _fileRows = null;
        _text.text = await file.readAsString();
      }
      if (mounted) {
        setState(() {
          _fileName = file.name;
          _rows = null;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted)
        setState(
          () => _error = CustomerPresentation.error(
            e,
            fallback: 'Unable to read import. Please try again.',
          ),
        );
    }
  }

  Future<void> _import() async {
    setState(() {
      _busy = true;
      _submitted = true;
    });
    try {
      await widget.database.importCatalog(_rows!, _request);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(
          () => _error = CustomerPresentation.error(
            e,
            fallback: 'Import failed. Retry preserves this request.',
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Import products')),
    body: ListView(
      padding: TrexvenSpacing.cardPadding,
      children: [
        OutlinedButton(
          onPressed: _busy || _submitted ? null : _chooseFile,
          child: Text('Choose CSV or Excel file'),
        ),
        if (_fileName != null) Text(_fileName!),
        Text(
          'Include a Product name column. Optional columns: Barcode, SKU, Category, Description, Image URL, Unit, Selling price, Low stock threshold, Initial quantity (new products), Stock delta and Stock reason (updates), Active, Group name, Size, Color and Material. Review each import before confirming. Blank prices preserve existing prices; new products stay pending until priced.',
        ),
        CheckboxListTile(
          title: Text('Update products matched by barcode or SKU'),
          value: _updateExisting,
          onChanged: _busy || _submitted
              ? null
              : (v) => setState(() {
                  _updateExisting = v ?? false;
                  _rows = null;
                }),
        ),
        TrexvenTextField(
          controller: _text,
          minLines: 5,
          maxLines: 12,
          enabled: !_busy && !_submitted,
          onChanged: (_) => setState(() {
            _rows = null;
            _fileRows = null;
            _fileName = null;
          }),
          decoration: TrexvenInputDecoration(labelText: 'CSV products'),
        ),
        if (_error != null)
          Text(
            _error!,
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
        OutlinedButton(
          onPressed: _busy || _submitted ? null : _review,
          child: Text('Review import'),
        ),
        if (_rows != null) ...[
          Text('${_rows!.length} products ready for review'),
          for (final r in _rows!)
            ListTile(
              title: Text(
                '${r['product_id'] == null ? 'Create' : 'Update'}: ${r['name']}',
              ),
              subtitle: Text(
                '${r['barcode'] ?? 'No barcode'} • ${r['selling_price'] == null ? (r['product_id'] == null ? 'Awaiting price' : 'Keep existing price') : CustomerPresentation.amount(r['selling_price'])} • ${r['product_id'] == null ? 'Opening quantity ${r['initial_quantity'] ?? 0}' : 'Stock change ${r['stock_delta'] ?? 0}'} ${r['unit'] ?? 'piece'}',
              ),
            ),
          FilledButton(
            onPressed: _busy ? null : _import,
            child: Text(_submitted ? 'Retry same import' : 'Confirm import'),
          ),
        ],
      ],
    ),
  );
}
