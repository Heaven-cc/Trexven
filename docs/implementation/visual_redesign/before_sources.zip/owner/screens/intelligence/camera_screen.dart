import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:trexven_operations/trexven_operations.dart';
import 'package:flutter/material.dart';

import '../../models/camera.dart';
import '../../services/vision_service.dart';
import 'add_camera_screen.dart';
import 'live_feed_screen.dart';

class CamerasScreen extends StatefulWidget {
  const CamerasScreen({super.key});

  @override
  State<CamerasScreen> createState() => _CamerasScreenState();
}

class _CamerasScreenState extends State<CamerasScreen> {
  final VisionService _intelligenceService = VisionService();

  bool _loading = true;
  String? _error;
  List<Camera> _cameras = [];

  @override
  void initState() {
    super.initState();
    _loadCameras();
  }

  Future<void> _loadCameras() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final cameras = await _intelligenceService.getCameras();

      if (!mounted) return;

      setState(() {
        _cameras = cameras;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = CustomerPresentation.error(
          e,
          fallback: 'We could not load this screen. Please try again.',
        );
      });
    }
  }

  Future<void> _addCamera() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AddCameraScreen()),
    );

    if (result == true) {
      _loadCameras();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final brandBlue = theme.colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text(
          'Cameras',
          style: TextStyle(
            fontSize: TrexvenFontSize.section,
            fontWeight: FontWeight.w800,
            color: theme.colorScheme.onSurface,
          ),
        ),
        actions: [
          IconButton(
            onPressed: _loadCameras,
            icon: Icon(
              Icons.refresh_rounded,
              color: theme.colorScheme.onSurface,
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addCamera,
        backgroundColor: brandBlue,
        icon: Icon(Icons.add, color: Colors.white),
        label: Text(
          'Add camera',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
        ),
      ),
      body: _buildBody(theme),
    );
  }

  Widget _buildBody(ThemeData theme) {
    final brandBlue = theme.colorScheme.primary;

    if (_loading) {
      return Center(child: CircularProgressIndicator(color: brandBlue));
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: TrexvenSpacing.pagePadding,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.error_outline_rounded,
                size: 50,
                color: Theme.of(context).colorScheme.error,
              ),
              SizedBox(height: 12),
              Text(
                'Could not load cameras',
                style: TextStyle(
                  fontSize: TrexvenFontSize.section,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 8),
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
              SizedBox(height: TrexvenSpacing.fieldGap),
              ElevatedButton(onPressed: _loadCameras, child: Text('Try again')),
            ],
          ),
        ),
      );
    }

    if (_cameras.isEmpty) {
      return _buildEmptyState(theme);
    }

    return RefreshIndicator(
      color: brandBlue,
      onRefresh: _loadCameras,
      child: ListView.builder(
        padding: EdgeInsets.fromLTRB(18, 10, 18, 100),
        itemCount: _cameras.length,
        itemBuilder: (context, index) {
          return _cameraCard(theme, _cameras[index]);
        },
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    final brandBlue = theme.colorScheme.primary;
    final muted = theme.trexvenColors.muted!;

    return Center(
      child: Padding(
        padding: EdgeInsets.all(30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: brandBlue.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(TrexvenRadii.card),
              ),
              child: Icon(Icons.videocam_outlined, size: 40, color: brandBlue),
            ),
            SizedBox(height: TrexvenSpacing.fieldGap),
            Text(
              'No cameras yet',
              style: TextStyle(
                fontSize: TrexvenFontSize.section,
                fontWeight: FontWeight.w800,
                color: theme.colorScheme.onSurface,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Add a camera to begin building your business intelligence system.',
              textAlign: TextAlign.center,
              style: TextStyle(color: muted, height: 1.5),
            ),
            SizedBox(height: TrexvenSpacing.fieldGap),
            ElevatedButton.icon(
              onPressed: _addCamera,
              icon: Icon(Icons.add),
              label: Text('Add camera'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _cameraCard(ThemeData theme, Camera camera) {
    final brandBlue = theme.colorScheme.primary;
    final muted = theme.trexvenColors.muted!;

    final status = camera.status.toLowerCase();
    final online = status == 'online';

    return Card(
      margin: EdgeInsets.only(bottom: 12),
      color: theme.trexvenColors.cardBackground,
      child: InkWell(
        borderRadius: BorderRadius.circular(TrexvenRadii.card),
        onTap: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => LiveFeedScreen(camera: camera)),
          );

          _loadCameras();
        },
        child: Padding(
          padding: TrexvenSpacing.cardPadding,
          child: Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: brandBlue.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(TrexvenRadii.card),
                ),
                child: Icon(Icons.videocam_rounded, color: brandBlue),
              ),
              SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      camera.name,
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: TrexvenFontSize.input,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      camera.location?.isNotEmpty == true
                          ? camera.location!
                          : 'Location not specified',
                      style: TextStyle(
                        fontSize: TrexvenFontSize.caption,
                        color: muted,
                      ),
                    ),
                    SizedBox(height: 8),
                    Row(
                      children: [
                        _statusDot(online),
                        SizedBox(width: 5),
                        Text(
                          online ? 'Online' : 'Offline',
                          style: TextStyle(
                            fontSize: TrexvenFontSize.caption,
                            fontWeight: FontWeight.w700,
                            color: online
                                ? (theme.trexvenColors.success!)
                                : muted,
                          ),
                        ),
                        SizedBox(width: 14),
                        Icon(
                          Icons.auto_awesome,
                          size: 13,
                          color: camera.aiEnabled
                              ? brandBlue
                              : muted.withValues(alpha: 0.5),
                        ),
                        SizedBox(width: 4),
                        Text(
                          camera.aiEnabled ? 'AI active' : 'AI off',
                          style: TextStyle(
                            fontSize: TrexvenFontSize.caption,
                            color: camera.aiEnabled
                                ? brandBlue
                                : muted.withValues(alpha: 0.5),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right_rounded,
                color: muted.withValues(alpha: 0.4),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statusDot(bool online) {
    return Container(
      width: 7,
      height: 7,
      decoration: BoxDecoration(
        color: online
            ? Theme.of(context).trexvenColors.success!
            : Theme.of(context).colorScheme.onSurfaceVariant,
        shape: BoxShape.circle,
      ),
    );
  }
}
