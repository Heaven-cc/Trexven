import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:trexven_operations/trexven_operations.dart';
import 'package:flutter/material.dart';

import '../../models/camera.dart';
import '../../services/camera_intelligence_service.dart';
import 'camera_event_screen.dart';
import 'camera_alert_screen.dart';

class CameraDetailScreen extends StatefulWidget {
  final Camera camera;

  const CameraDetailScreen({super.key, required this.camera});

  @override
  State<CameraDetailScreen> createState() => _CameraDetailScreenState();
}

class _CameraDetailScreenState extends State<CameraDetailScreen> {
  final CameraIntelligenceService _intelligenceService =
      CameraIntelligenceService();

  late Camera _camera;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _camera = widget.camera;
  }

  Future<void> _toggleAI(bool enabled) async {
    setState(() {
      _loading = true;
    });

    try {
      await _intelligenceService.setAiEnabled(_camera.id, enabled);

      if (!mounted) return;

      setState(() {
        _camera = _camera.copyWith(aiEnabled: enabled);
        _loading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            enabled
                ? 'Camera intelligence enabled.'
                : 'Camera intelligence disabled.',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            CustomerPresentation.error(
              e,
              fallback: 'Could not update AI. Please try again.',
            ),
          ),
        ),
      );
    }
  }

  Future<void> _deleteCamera() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        scrollable: true,
        title: Text('Delete camera?'),
        content: Text('This will remove this camera from the business.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      await _intelligenceService.deleteCamera(_camera.id);

      if (!mounted) return;

      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            CustomerPresentation.error(
              e,
              fallback: 'Could not delete camera. Please try again.',
            ),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.trexvenColors.muted!;
    final brandBlue = theme.colorScheme.primary;
    final online = _camera.status.toLowerCase() == 'online';

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text(
          'Camera',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            color: theme.colorScheme.onSurface,
          ),
        ),
        actions: [
          IconButton(
            onPressed: _deleteCamera,
            icon: Icon(
              Icons.delete_outline_rounded,
              color: theme.trexvenColors.error,
            ),
          ),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.all(18),
        children: [
          Container(
            height: 210,
            decoration: BoxDecoration(
              color: theme.brightness == Brightness.dark
                  ? theme.colorScheme.surface
                  : theme.trexvenColors.brandDark,
              borderRadius: BorderRadius.circular(TrexvenRadii.card),
            ),
            child: Center(
              child: Icon(
                Icons.videocam_rounded,
                color: Colors.white54,
                size: 60,
              ),
            ),
          ),
          SizedBox(height: TrexvenSpacing.fieldGap),
          Text(
            _camera.name,
            style: TextStyle(
              fontSize: TrexvenFontSize.title,
              fontWeight: FontWeight.w800,
              color: theme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 6),
          Text(
            _camera.location?.isNotEmpty == true
                ? _camera.location!
                : 'Location not specified',
            style: TextStyle(color: muted),
          ),
          SizedBox(height: TrexvenSpacing.fieldGap),
          _infoCard(
            theme,
            title: 'Connection',
            icon: Icons.wifi_rounded,
            value: online ? 'Online' : 'Offline',
            valueColor: online ? (theme.trexvenColors.success!) : muted,
          ),
          SizedBox(height: 12),
          Card(
            color: theme.trexvenColors.cardBackground,
            child: SwitchListTile(
              value: _camera.aiEnabled,
              onChanged: _loading ? null : _toggleAI,
              title: Text(
                'Camera Intelligence',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              subtitle: Text(
                _camera.aiEnabled
                    ? 'AI analysis is enabled'
                    : 'AI analysis is disabled',
                style: TextStyle(color: muted),
              ),
              secondary: Icon(Icons.auto_awesome, color: brandBlue),
            ),
          ),
          SizedBox(height: TrexvenSpacing.fieldGap),
          _actionTile(
            theme,
            icon: Icons.timeline_rounded,
            title: 'Camera Events',
            subtitle: 'View detected activity',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CameraEventsScreen(camera: _camera),
                ),
              );
            },
          ),
          SizedBox(height: 10),
          _actionTile(
            theme,
            icon: Icons.warning_amber_rounded,
            title: 'Camera Alerts',
            subtitle: 'Review important security events',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CameraAlertsScreen(camera: _camera),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _infoCard(
    ThemeData theme, {
    required String title,
    required IconData icon,
    required String value,
    required Color valueColor,
  }) {
    return Card(
      color: theme.trexvenColors.cardBackground,
      child: ListTile(
        leading: Icon(icon, color: theme.colorScheme.primary),
        title: Text(
          title,
          style: TextStyle(color: theme.colorScheme.onSurface),
        ),
        trailing: Text(
          value,
          style: TextStyle(color: valueColor, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }

  Widget _actionTile(
    ThemeData theme, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    final muted = theme.trexvenColors.muted!;

    return Card(
      color: theme.trexvenColors.cardBackground,
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundColor: theme.colorScheme.primary.withValues(alpha: 0.08),
          child: Icon(icon, color: theme.colorScheme.primary),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.w800,
            color: theme.colorScheme.onSurface,
          ),
        ),
        subtitle: Text(subtitle, style: TextStyle(color: muted)),
        trailing: Icon(
          Icons.chevron_right_rounded,
          color: muted.withValues(alpha: 0.4),
        ),
      ),
    );
  }
}
