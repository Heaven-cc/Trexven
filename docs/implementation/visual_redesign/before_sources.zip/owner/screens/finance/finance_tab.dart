import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../models/sale.dart';
import 'record_sale_screen.dart';
import 'operational_finance_screen.dart';

class FinanceTab extends StatefulWidget {
  const FinanceTab({super.key, this.database});
  final DatabaseService? database;
  @override
  State<FinanceTab> createState() => _FinanceTabState();
}

class _FinanceTabState extends State<FinanceTab> {
  late final DatabaseService _db;
  late Future<List<Sale>> _sales;
  late Future<Map<String, dynamic>> _stats;
  Future<void>? _refreshing;

  @override
  void initState() {
    super.initState();
    _db = widget.database ?? DatabaseService();
    _loadData();
  }

  void _loadData() {
    _sales = _db
        .getSalesWithProductNames(limit: 50)
        .timeout(Duration(seconds: 20));
    _stats = _db.getTodayStats().timeout(Duration(seconds: 20));
  }

  Future<void> _refresh() {
    if (_refreshing != null) return _refreshing!;
    setState(_loadData);
    // FutureBuilders display the individual failures; refresh still finishes.
    return _refreshing = Future.wait<Object>([_sales, _stats])
        .then<void>((_) {}, onError: (Object _, StackTrace __) {})
        .whenComplete(() => _refreshing = null);
  }

  Widget _retry(String message) => Column(
    children: [
      Text(message),
      TextButton(onPressed: _refresh, child: Text('Retry')),
    ],
  );

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.trexvenColors.muted!;

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: CustomScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverPadding(
              padding: TrexvenSpacing.pagePadding,
              sliver: SliverToBoxAdapter(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Finance',
                      style: TextStyle(
                        fontSize: TrexvenSpacing.pageTitle,
                        fontWeight: FontWeight.w800,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Understand your business finances.',
                      style: TextStyle(
                        color: muted,
                        fontSize: TrexvenFontSize.body,
                      ),
                    ),
                    SizedBox(height: TrexvenSpacing.sectionGap),
                    OutlinedButton.icon(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => OperationalFinanceScreen(),
                        ),
                      ),
                      icon: Icon(Icons.receipt_long),
                      label: Text('Credit, repayments and returns'),
                    ),
                    _liveRevenueHero(context),
                    SizedBox(height: TrexvenSpacing.fieldGap),
                    Text(
                      'Recent Transactions',
                      style: TextStyle(
                        fontSize: TrexvenFontSize.section,
                        fontWeight: FontWeight.w800,
                        color: theme.colorScheme.onSurface,
                      ),
                    ),
                    SizedBox(height: 12),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 100),
              sliver: FutureBuilder<List<Sale>>(
                // `sales` has no product-name column of its own, so this
                // resolves each sale's product name via a one-shot products
                // lookup rather than the raw table stream.
                future: _sales,
                builder: (context, snapshot) {
                  if (!snapshot.hasData &&
                      snapshot.connectionState == ConnectionState.waiting) {
                    return SliverToBoxAdapter(
                      child: Center(
                        child: CircularProgressIndicator(
                          color: theme.colorScheme.primary,
                        ),
                      ),
                    );
                  }
                  if (snapshot.hasError)
                    return SliverToBoxAdapter(
                      child: _retry(
                        'Unable to load transactions. Please retry.',
                      ),
                    );
                  final sales = snapshot.data ?? [];
                  if (sales.isEmpty) {
                    return SliverToBoxAdapter(
                      child: Center(
                        child: Text(
                          'No transactions recorded yet',
                          style: TextStyle(color: muted),
                        ),
                      ),
                    );
                  }
                  return SliverList.builder(
                    itemCount: sales.length,
                    itemBuilder: (context, index) {
                      final sale = sales[index];
                      return ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(
                          sale.productName.isEmpty
                              ? 'Product'
                              : sale.productName,
                          style: TextStyle(
                            color: theme.colorScheme.onSurface,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        subtitle: Text(
                          'Qty: ${sale.quantity}',
                          style: TextStyle(
                            color: muted,
                            fontSize: TrexvenFontSize.body,
                          ),
                        ),
                        trailing: Text(
                          '₦${sale.totalPrice}',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: theme.colorScheme.primary,
                            fontSize: TrexvenFontSize.input,
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => RecordSaleScreen()),
          );
          if (mounted) await _refresh();
        },
        label: Text('Record Sale', style: TextStyle(color: Colors.white)),
        icon: Icon(Icons.add, color: Colors.white),
        backgroundColor: theme.colorScheme.primary,
      ),
    );
  }

  Widget _liveRevenueHero(BuildContext context) {
    final theme = Theme.of(context);

    return FutureBuilder<Map<String, dynamic>>(
      future: _stats,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return _retry('Unable to load revenue. Please retry.');
        if (!snapshot.hasData) return Center(child: TrexvenLoading());
        final revenue = snapshot.data?['sales'] ?? 0.0;
        return Container(
          width: double.infinity,
          padding: TrexvenSpacing.cardPadding,
          decoration: BoxDecoration(
            color: theme.brightness == Brightness.dark
                ? theme.colorScheme.surface
                : theme.trexvenColors.brandDark,
            borderRadius: BorderRadius.circular(TrexvenRadii.card),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Today's Revenue",
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.6),
                  fontSize: TrexvenFontSize.body,
                ),
              ),
              SizedBox(height: 8),
              Text(
                '₦$revenue',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: TrexvenFontSize.display,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
