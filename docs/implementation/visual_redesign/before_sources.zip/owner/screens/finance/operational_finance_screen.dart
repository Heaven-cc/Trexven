import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:trexven_operations/trexven_operations.dart';
import '../../services/database_service.dart';

class OperationalFinanceScreen extends StatefulWidget {
  const OperationalFinanceScreen({super.key});
  @override
  State<OperationalFinanceScreen> createState() =>
      _OperationalFinanceScreenState();
}

class _OperationalFinanceScreenState extends State<OperationalFinanceScreen> {
  late final Future<String?> business = DatabaseService()
      .getCurrentBusinessId();
  @override
  Widget build(BuildContext context) => FutureBuilder<String?>(
    future: business,
    builder: (context, snapshot) {
      if (snapshot.connectionState != ConnectionState.done)
        return Scaffold(body: Center(child: TrexvenLoading()));
      if (snapshot.hasError || snapshot.data == null)
        return Scaffold(
          body: Center(
            child: TrexvenEmptyState(
              title: 'Verified owner business required.',
            ),
          ),
        );
      final api = OperationsClient(Supabase.instance.client, snapshot.data!);
      return Scaffold(
        appBar: AppBar(title: Text('Business operations')),
        body: ListView(
          children: [
            ListTile(
              title: Text('Credit and returns'),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      FinancialOperationsScreen(api: api, owner: true),
                ),
              ),
            ),
            ListTile(
              title: Text('Inventory operations'),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => InventoryOperationsScreen(api: api),
                ),
              ),
            ),
            ListTile(
              title: Text('Shared cash drawers'),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CashShiftScreen(api: api, owner: true),
                ),
              ),
            ),
            ListTile(
              title: Text('Operational employee permissions'),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => OperationalPermissionsScreen(api: api),
                ),
              ),
            ),
          ],
        ),
      );
    },
  );
}
