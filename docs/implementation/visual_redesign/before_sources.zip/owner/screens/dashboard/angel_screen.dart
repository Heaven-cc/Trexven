import 'package:trexven_design_system/trexven_design_system.dart';
import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../widgets/angel_markdown.dart';
import '../../services/database_service.dart';

class AngelScreen extends StatefulWidget {
  const AngelScreen({super.key});

  @override
  State<AngelScreen> createState() => _AngelScreenState();
}

class _AngelScreenState extends State<AngelScreen> {
  final TextEditingController _messageController = TextEditingController();

  final ScrollController _scrollController = ScrollController();

  final List<_AngelMessage> _messages = [];

  bool _loadingHistory = true;
  String? _conversationId;
  bool _isThinking = false;

  final SupabaseClient _supabase = Supabase.instance.client;

  final _db = DatabaseService();

  @override
  void initState() {
    super.initState();

    _messages.add(
      const _AngelMessage(
        text:
            "Hello. I'm Angel. I'm here to help you understand and manage your business.",
        isAngel: true,
      ),
    );
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    try {
      final businessId = await _db.requireBusinessId();
      final userId = _supabase.auth.currentUser?.id;
      if (userId == null) throw StateError('Sign in to use Angel.');
      final conversation = await _supabase
          .from('angel_conversations')
          .select('id')
          .eq('business_id', businessId)
          .eq('user_id', userId)
          .order('updated_at', ascending: false)
          .limit(1)
          .maybeSingle();
      if (conversation != null) {
        final history = await _supabase
            .from('angel_messages')
            .select('role,content')
            .eq('conversation_id', conversation['id'])
            .order('created_at', ascending: false)
            .limit(100);
        if (!mounted) return;
        setState(() {
          _conversationId = conversation['id'] as String;
          if (history.isNotEmpty) {
            _messages.clear();
            _messages.addAll(
              history.reversed.map(
                (row) => _AngelMessage(
                  text: row['content'] as String,
                  isAngel: row['role'] == 'assistant',
                ),
              ),
            );
          }
        });
        _scrollToBottom();
      }
    } catch (_) {
      if (mounted)
        _showError('Unable to load Angel history. Reopen Angel to retry.');
    } finally {
      if (mounted) setState(() => _loadingHistory = false);
    }
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ============================================================
  // SEND MESSAGE TO ANGEL
  // ============================================================

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();

    if (text.isEmpty || _isThinking || _loadingHistory) {
      return;
    }

    // Add user's message immediately.
    setState(() {
      _messages.add(_AngelMessage(text: text, isAngel: false));

      _messageController.clear();
      _isThinking = true;
    });

    _scrollToBottom();

    try {
      final response = await _supabase.functions
          .invoke(
            'angel',
            body: {
              'business_id': await _db.requireBusinessId(),
              'message': text,
              'timezone_offset_minutes':
                  DateTime.now().timeZoneOffset.inMinutes,
              if (_conversationId != null) 'conversation_id': _conversationId,
            },
          )
          .timeout(Duration(seconds: 30));

      if (!mounted) return;

      final data = response.data;

      if (data == null) {
        throw Exception('Angel returned an empty response.');
      }

      Map<String, dynamic> result;

      if (data is Map<String, dynamic>) {
        result = data;
      } else if (data is Map) {
        result = Map<String, dynamic>.from(data);
      } else if (data is String) {
        result = jsonDecode(data);
      } else {
        throw Exception('Invalid response from Angel.');
      }

      if (result['success'] != true) {
        throw Exception(
          result['details']?.toString().isNotEmpty == true
              ? '${result['error'] ?? 'Angel could not process your request.'}\n${result['details']}'
              : result['error']?.toString() ??
                    'Angel could not process your request.',
        );
      }

      final answer = result['reply']?.toString().trim();

      if (answer == null || answer.isEmpty) {
        throw Exception('Angel returned an empty answer.');
      }

      setState(() {
        _conversationId = result['conversation_id'] as String?;
        _messages.add(_AngelMessage(text: answer, isAngel: true));

        _isThinking = false;
      });

      _scrollToBottom();
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _isThinking = false;
      });

      _showError(
        error is TimeoutException
            ? 'Angel could not connect in time. Check your connection and try again.'
            : error is FunctionException && error.status == 503
            ? 'Angel is temporarily unavailable. Please try again later.'
            : 'Angel could not answer right now. Please try again.',
      );
    }
  }

  // ============================================================
  // ERROR MESSAGE
  // ============================================================

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 4),
      ),
    );
  }

  // ============================================================
  // VOICE
  // ============================================================

  // ============================================================
  // SCROLL
  // ============================================================

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_scrollController.hasClients) {
        return;
      }

      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    });
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.trexvenColors.muted!;

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_rounded,
            color: theme.colorScheme.onSurface,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: theme.colorScheme.primary.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(TrexvenRadii.card),
              ),
              child: Icon(
                Icons.auto_awesome,
                color: theme.colorScheme.primary,
                size: 20,
              ),
            ),
            SizedBox(width: 11),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Angel',
                  style: TextStyle(
                    fontSize: TrexvenFontSize.section,
                    fontWeight: FontWeight.w800,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                SizedBox(height: 1),
                Text(
                  'Business intelligence',
                  style: TextStyle(
                    fontSize: TrexvenFontSize.caption,
                    color: muted,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _loadingHistory
                ? Center(child: TrexvenLoading())
                : ListView.builder(
                    controller: _scrollController,
                    padding: EdgeInsets.fromLTRB(18, 15, 18, 20),
                    itemCount: _messages.length + (_isThinking ? 1 : 0),
                    itemBuilder: (context, index) {
                      if (_isThinking && index == _messages.length) {
                        return _buildThinkingBubble();
                      }
                      return _buildMessage(_messages[index]);
                    },
                  ),
          ),
          _buildSuggestionArea(),
          SafeArea(top: false, child: _buildInputArea()),
        ],
      ),
    );
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  Widget _buildMessage(_AngelMessage message) {
    final theme = Theme.of(context);
    final isAngel = message.isAngel;

    return Align(
      alignment: isAngel ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * .82,
        ),
        margin: EdgeInsets.only(bottom: 12),
        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 12),
        decoration: BoxDecoration(
          color: isAngel
              ? theme.trexvenColors.cardBackground
              : theme.colorScheme.primary,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(18),
            topRight: Radius.circular(18),
            bottomLeft: Radius.circular(isAngel ? 4 : 18),
            bottomRight: Radius.circular(isAngel ? 18 : 4),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (isAngel)
              Padding(
                padding: EdgeInsets.only(bottom: 5),
                child: Text(
                  'ANGEL',
                  style: TextStyle(
                    fontSize: TrexvenFontSize.caption,
                    fontWeight: FontWeight.w800,
                    letterSpacing: .8,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),
            if (isAngel)
              AngelMarkdown(data: message.text)
            else
              SelectableText(
                message.text,
                style: TextStyle(
                  fontSize: TrexvenFontSize.body,
                  height: 1.45,
                  color: isAngel ? theme.colorScheme.onSurface : Colors.white,
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // THINKING
  // ============================================================

  Widget _buildThinkingBubble() {
    final theme = Theme.of(context);

    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(bottom: 12),
        padding: EdgeInsets.symmetric(horizontal: 17, vertical: 14),
        decoration: BoxDecoration(
          color: theme.trexvenColors.cardBackground,
          borderRadius: BorderRadius.circular(TrexvenRadii.card),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: theme.colorScheme.primary,
              ),
            ),
            SizedBox(width: 10),
            Text(
              'Angel is thinking...',
              style: TextStyle(
                fontSize: TrexvenFontSize.caption,
                color: theme.trexvenColors.muted,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // SUGGESTIONS
  // ============================================================

  Widget _buildSuggestionArea() {
    return SizedBox(
      height: 48,

      child: ListView(
        scrollDirection: Axis.horizontal,

        padding: EdgeInsets.symmetric(horizontal: 16),

        children: [
          _suggestion('How are sales today?'),

          _suggestion('Check my stock'),

          _suggestion('Any unusual activity?'),

          _suggestion('What happened today?'),
        ],
      ),
    );
  }

  Widget _suggestion(String text) {
    final theme = Theme.of(context);

    return Padding(
      padding: EdgeInsets.only(right: 8, bottom: 4),
      child: ActionChip(
        label: Text(text),
        backgroundColor: theme.trexvenColors.cardBackground,
        onPressed: _isThinking || _loadingHistory
            ? null
            : () {
                _messageController.text = text;
                _sendMessage();
              },
      ),
    );
  }

  // ============================================================
  // INPUT
  // ============================================================

  Widget _buildInputArea() {
    final theme = Theme.of(context);

    return Container(
      padding: EdgeInsets.fromLTRB(14, 10, 14, 14),
      decoration: BoxDecoration(color: theme.trexvenColors.cardBackground),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: theme.scaffoldBackgroundColor,
                borderRadius: BorderRadius.circular(TrexvenRadii.card),
              ),
              child: TrexvenTextField(
                variant: TrexvenFieldVariant.chat,
                gap: 0,
                enabled: !_loadingHistory && !_isThinking,
                controller: _messageController,
                minLines: 1,
                maxLines: 5,
                textInputAction: TextInputAction.newline,
                decoration: TrexvenInputDecoration(
                  hintText: 'Message Angel...',
                ),
                onSubmitted: (_) {
                  _sendMessage();
                },
              ),
            ),
          ),
          SizedBox(width: 8),
          IconButton.filled(
            tooltip: 'Send message',
            onPressed: _loadingHistory || _isThinking ? null : _sendMessage,
            constraints: BoxConstraints(minWidth: 48, minHeight: 48),
            icon: Icon(Icons.arrow_upward_rounded, size: 22),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// MESSAGE MODEL
// ============================================================

class _AngelMessage {
  final String text;
  final bool isAngel;

  const _AngelMessage({required this.text, required this.isAngel});
}
