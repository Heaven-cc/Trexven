import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:flutter/material.dart';
import '../widgets/trexven_logo.dart';
import 'auth/register_screen.dart';
import 'auth/login_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.trexvenColors.muted!;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 26),
          child: Column(
            children: [
              Spacer(),
              TrexvenLogo(size: 70),
              SizedBox(height: TrexvenSpacing.fieldGap),
              Text(
                'TREXVEN',
                style: TextStyle(
                  fontSize: TrexvenFontSize.title,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              SizedBox(height: TrexvenSpacing.sectionGap),
              Text(
                'Run your business\nsmarter.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: TrexvenFontSize.display,
                  height: 1.12,
                  fontWeight: FontWeight.w800,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              SizedBox(height: TrexvenSpacing.fieldGap),
              Text(
                'Manage your store, inventory, employees, sales '
                'and security from one powerful platform.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: TrexvenFontSize.input,
                  height: 1.6,
                  color: muted,
                ),
              ),
              Spacer(),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => RegisterScreen()),
                  );
                },
                child: Text('Create an Account'),
              ),
              SizedBox(height: 12),
              OutlinedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => LoginScreen()),
                  );
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: theme.colorScheme.onSurface,
                ),
                child: Text(
                  'Sign In',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              SizedBox(height: TrexvenSpacing.sectionGap),
              Text(
                'Secure • Simple • Built for growing businesses',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: TrexvenFontSize.caption,
                  color: theme.trexvenColors.muted?.withValues(alpha: 0.6),
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: TrexvenSpacing.fieldGap),
            ],
          ),
        ),
      ),
    );
  }
}
