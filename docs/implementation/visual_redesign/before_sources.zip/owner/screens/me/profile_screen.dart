import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:trexven_operations/trexven_operations.dart';
import '../../core/user_provider.dart';

class ProfileScreen extends StatefulWidget {
  final String initialName;
  const ProfileScreen({super.key, required this.initialName});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  bool _saving = false;
  @override
  void initState() {
    super.initState();
    final user = Supabase.instance.client.auth.currentUser;
    _name = TextEditingController(
      text: user?.userMetadata?['full_name'] as String? ?? widget.initialName,
    );
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_saving || !_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    setState(() => _saving = true);
    try {
      await context.read<UserProvider>().updateMetadata({
        'full_name': _name.text.trim(),
      });
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Your profile has been updated.')));
      Navigator.pop(context);
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              CustomerPresentation.error(
                error,
                fallback: 'We could not save your profile. Please try again.',
              ),
            ),
          ),
        );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final user = Supabase.instance.client.auth.currentUser;
    return Scaffold(
      appBar: AppBar(title: Text('My Profile')),
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: TrexvenSpacing.pagePadding,
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: 560),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 22,
                          backgroundColor: theme.colorScheme.primary.withValues(
                            alpha: .1,
                          ),
                          child: Icon(
                            Icons.person_outline_rounded,
                            color: theme.colorScheme.primary,
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Your profile',
                                style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                'Keep your account details up to date.',
                                style: theme.textTheme.bodySmall,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: TrexvenSpacing.sectionGap),
                    TrexvenTextFormField(
                      controller: _name,
                      enabled: !_saving,
                      maxLength: 100,
                      textCapitalization: TextCapitalization.words,
                      textInputAction: TextInputAction.done,
                      autofillHints: [AutofillHints.name],
                      onFieldSubmitted: (_) => _save(),
                      validator: (value) => (value?.trim().length ?? 0) < 2
                          ? 'Enter your full name.'
                          : null,
                      decoration: TrexvenInputDecoration(
                        labelText: 'Full name',
                        counterText: '',
                        prefixIcon: Icon(Icons.person_outline),
                      ),
                    ),
                    Text('Email address', style: theme.textTheme.labelLarge),
                    SizedBox(height: 6),
                    SelectableText(
                      user?.email ?? 'Email unavailable',
                      style: theme.textTheme.bodyMedium,
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Your sign-in email is read-only here.',
                      style: theme.textTheme.bodySmall,
                    ),
                    SizedBox(height: TrexvenSpacing.sectionGap),
                    TrexvenButton(
                      text: 'Save Changes',
                      onPressed: _saving ? null : _save,
                      isLoading: _saving,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
