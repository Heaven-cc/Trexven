import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:flutter/material.dart';
import 'package:trexven_operations/trexven_operations.dart';

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final VoidCallback? onTap;

  const StatCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final brandBlue = theme.colorScheme.primary;
    final muted = theme.trexvenColors.muted!;
    final errorColor = theme.trexvenColors.error!;

    final bool isLowStock = title.toLowerCase().contains('low stock');

    return TrexvenTapCard(
      onTap: onTap,
      padding: EdgeInsets.all(12),
      borderRadius: TrexvenRadii.card,
      backgroundColor: theme.colorScheme.primary.withValues(alpha: 0.05),
      child: MetricContent(
        title: title,
        value: value,
        icon: icon,
        color: isLowStock ? errorColor : brandBlue,
        valueStyle: TextStyle(
          fontSize: TrexvenFontSize.title,
          fontWeight: FontWeight.w800,
          color: theme.colorScheme.onSurface,
          height: 1.1,
        ),
        titleStyle: TextStyle(
          fontSize: TrexvenFontSize.body,
          fontWeight: FontWeight.w500,
          color: muted,
        ),
      ),
    );
  }
}
