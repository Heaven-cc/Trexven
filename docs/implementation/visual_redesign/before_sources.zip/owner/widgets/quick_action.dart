import 'package:trexven_design_system/trexven_design_system.dart';
import 'package:flutter/material.dart';

class QuickAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback? onTap;

  const QuickAction({
    super.key,
    required this.icon,
    required this.title,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final brandBlue = theme.colorScheme.primary;

    return TrexvenTapCard(
      onTap: onTap,
      borderRadius: TrexvenRadii.card,
      padding: EdgeInsets.symmetric(horizontal: 14, vertical: 17),
      child: Row(
        children: [
          Icon(icon, color: brandBlue, size: 21),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: TrexvenFontSize.body,
                color: theme.colorScheme.onSurface,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
